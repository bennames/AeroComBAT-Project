from setuptools import setup
import AeroComBAT

setup(
    name='AeroComBAT',
    description=AeroComBAT.__doc__,
    author='Ben Names',
    author_email='bennames@vt.edu',
    packages=['AeroComBAT'],
    version='1.0a1',
    license='MIT',
    url='https://github.com/bennames/AeroComBAT-Project',
    install_requires=[
        'numpy',
        'mayavi',
        'numba'],
    classifiers=[
    # How mature is this project? Common values are
    #   3 - Alpha
    #   4 - Beta
    #   5 - Production/Stable
    'Development Status :: 3 - Alpha',

    # Indicate who your project is intended for
    'Intended Audience :: Aerospace Stress Analysts',

    # Pick your license as you wish (should match "license" above)
     'License :: OSI Approved :: MIT License',

    # Specify the Python versions you support here. In particular, ensure
    # that you indicate whether you support Python 2, Python 3 or both.
    'Programming Language :: Python :: 2.7',],
    )