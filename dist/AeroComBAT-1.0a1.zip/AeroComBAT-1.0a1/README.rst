=======================
AeroComBAT Introduction
=======================

AeroComBAT (Aeroelastic Composite Beam Analysis Tool) is a python API intended
to allow users to efficiently models composite beam structures.

:Authors: 
    Ben Names

:Version: 1.0 of 2016/04/16

Version 1.0 
===========
Capabilities
------------
- Simple classical lamination theory analysis
- Cross-sectional analysis of composite beams
- 3D Timoshenko (shear deformable) beam analysis
  + Linear static analysis
  + Normal mode analysis
  + Dynamic Aeroelastic Stability (Flutter) Analysis

Tutorials
---------
For for AeroComBAT Tutorials, see `AeroComBAT Tutorials
<http://www.python.org/>`_.

Installation Instructions
-------------------------
